syms y t f(t)
f = exp(-3*t);
tstart=0;
y0=1;
T=0.1;
n=6;

eulerscript(f,tstart,y0,T,n)

syms y(t) t f(t,y) f2(t) x
f = exp(-3*t) -y;
f2 = exp(-3*t) -x;
tstart=0;
y0=1;
T=0.1;
n=6;

eulerscript2(f,f2,tstart,y0,T,n)
