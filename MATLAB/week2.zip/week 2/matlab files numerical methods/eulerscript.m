% Does a simple Euler integration for 
% function f in symbolic format
% and produces a plot of the solution
%
% tstart - the initial time
% y0     - the initial state
% T      - the sample period
% n      - number of samples

function eulerscript(f,tstart,y0,T,n)

tt = tstart;  % initial time
y = y0;      % initial state

for k=2:n;
    tt(k)=tt(k-1)+T;
    gradient = subs(f,tt(k-1));
    y(k) = y(k-1) + T*gradient;
end

figure(1); clf reset
plot(tt,y,'b-o','linewidth',2); 
grid on; hold on;
xlabel('Time')
ylabel('State')
title('Solution of model using Euler')

% Analytical solution
syms x(t);
Dx = diff(x);
g=dsolve(f==Dx,x(0)==y0);
t2 = linspace(tstart,tt(end),101);
gt = subs(g,t2);
plot(t2,gt,'r--','linewidth',2);