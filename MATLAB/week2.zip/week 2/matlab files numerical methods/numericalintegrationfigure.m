% Sketch of numericla integration
x = linspace(-1,2,101);
y = 2+ x +x.^2;
figure(1); clf reset
plot(x,y,'linewidth',2)
grid; hold on
x1=0.5; y1 = 2+ x1 +x1.^2;
gradient = 1+2*x1;
x2=1.5; y2 = y1 + gradient*(x2-x1); 
fill([x1,x2,x2,x1],[0,0,y2,y1],'y')
fill([x1,x2,x2,x1],[0,0,y1,y1],'g')

x3=-0.4; x4=-0.2;
y3 = 2+x3+x3^2.
fill([x3,x4,x4,x3],[0,0,y3,y3],'r')
