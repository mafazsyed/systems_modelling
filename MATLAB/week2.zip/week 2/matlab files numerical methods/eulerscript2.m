% Does a simple Euler integration for 
% function f in symbolic format
% Assumes that f is a function of both time and state.
% 
% produces a plot of the solution
%
% tstart - the initial time
% y0     - the initial state
% T      - the sample period
% n      - number of samples

function eulerscript2(f,f2,tstart,y0,T,n)

syms t x y(t)
tt = tstart;  % initial time
yy = y0;      % initial state

for k=2:n;
    tt(k)=tt(k-1)+T;
   gradient = subs(f2,{t,x},{tt(k-1),yy(k-1)})  
    yy(k) = yy(k-1) + T*gradient;
end

figure(1); clf reset
plot(tt,yy,'b-o','linewidth',2); 
grid on; hold on;
xlabel('Time')
ylabel('State')
title('Solution of model using Euler')

% Analytical solution
syms t y(t);
Dy = diff(y);
g=dsolve(Dy-f==0,y(0)==y0);
t2 = linspace(tstart,tt(end),101);
gt = subs(g,t2);
plot(t2,gt,'r--','linewidth',2);