M=700;
k1=7500;
k2=170000;
b=5500;
v=20;
l=2;
h=0.3;
time=[0;10/v;(10+1)/v;50/v];
ground=[0;0;h;h];
t_stop=300/v;
profile=[0 0;10/v 0;(10+1)/v h;50/v h];

sim("Car_Susp.mdl");
% Data is in the structure wheelgroundcar
figure(1);
plot(wheelgroundcar.time,wheelgroundcar.signals.values,'LineWidth',2)
grid
legend('Wheel','Ground','Car')
title('Figure for task 3')
xlabel('Seconds')

% Collect and plot results from 3 simulations
Task3 = wheelgroundcar;
Car_Susp_Variables_Task2;
Task2 = wheelgroundcar;
Car_Susp_Variables
Task1 = wheelgroundcar;
figure(2); clf reset
plot(Task1.time,Task1.signals.values(:,3),'LineWidth',2); hold on
plot(Task2.time,Task2.signals.values(:,3),'LineWidth',2); hold on
plot(Task3.time,Task3.signals.values(:,3),'LineWidth',2); hold on
grid
legend('Task 1','Task 2','Task 3')
title('Car movement for all 3 tasks')
xlabel('Seconds')

