M=500;
k1=7500;
k2=170000;
b=1250;
v=10;
l=2;
h=0.3;
time=[0;10/v;(10+1)/v;50/v];
ground=[0;0;h;h];
t_stop=50/v;
profile=[0 0;10/v 0;(10+1)/v h;50/v h];

sim("Car_Susp.mdl");
% Data is in the structure wheelgroundcar
figure(1);
plot(wheelgroundcar.time,wheelgroundcar.signals.values,'LineWidth',2)
grid
legend('Wheel','Ground','Car')
title('Figure for task 1')
xlabel('Seconds')
